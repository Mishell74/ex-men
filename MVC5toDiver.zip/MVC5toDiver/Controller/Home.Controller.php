<?php
	Class Home
    {
        public function Inicio()
        {
         
        }
    }
?>